#!/bin/bash
gcc -pthread p3200143-res.c -o output && ./output 100 1000
chmod +x test.sh
